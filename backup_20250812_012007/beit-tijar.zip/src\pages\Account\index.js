import React from "react";

const Account = () => {
  return (
    <div className="container mt-5">
      <h2>صفحة الحساب الشخصي</h2>
      <p>هنا يمكن عرض بيانات المستخدم أو تعديلها</p>
    </div>
  );
};

export default Account;
