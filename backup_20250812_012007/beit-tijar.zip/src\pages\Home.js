import React from "react";

const Home = () => {
  return (
    <div className="container mt-5">
      <h1>مرحبًا بكم في بيت_تجار</h1>
      <p>أفضل منصة للإعلانات العقارية</p>
    </div>
  );
};

export default Home;